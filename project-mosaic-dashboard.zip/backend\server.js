import express from 'express'
import cors from 'cors'
import { BigQuery } from '@google-cloud/bigquery'
import { KPIS } from './kpis.js'

const PORT = process.env.PORT || 4000
const PROJECT_ID = process.env.GCP_PROJECT || 'cio-mosaic-analytics-pr-853ae3'
const CACHE_TTL_MS = 60_000

const bq = new BigQuery({ projectId: PROJECT_ID })
const cache = new Map()

const app = express()
app.use(cors())

app.get('/api/kpi/:id', async (req, res) => {
  const { id } = req.params
  const kpi = KPIS[id]
  if (!kpi) return res.status(404).json({ error: `Unknown KPI: ${id}` })

  const cached = cache.get(id)
  if (cached && Date.now() - cached.at < CACHE_TTL_MS) {
    return res.json(cached.payload)
  }

  try {
    const [rows] = await bq.query({ query: kpi.sql })
    const value = kpi.extract ? kpi.extract(rows[0]) : rows[0]
    const payload = { id, label: kpi.label, value, fetchedAt: new Date().toISOString() }
    cache.set(id, { at: Date.now(), payload })
    res.json(payload)
  } catch (err) {
    console.error(`[kpi:${id}]`, err.message)
    res.status(500).json({ error: err.message })
  }
})

app.get('/api/health', (_req, res) => res.json({ ok: true }))

app.listen(PORT, () => {
  console.log(`backend listening on http://localhost:${PORT} (project=${PROJECT_ID})`)
})
